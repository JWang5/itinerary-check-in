/// <reference types="react" />
import type { AnimatedNavbarProps } from '../types';
declare const AnimatedNavbar: ({ scroll, imageHeight, OverflowHeaderComponent, TopNavbarComponent, headerHeight, headerElevation, }: AnimatedNavbarProps) => JSX.Element;
export default AnimatedNavbar;
//# sourceMappingURL=AnimatedNavbar.d.ts.map