import { Animated } from 'react-native';
export declare const useAnimateScrollView: (imageHeight: number, disableScale?: boolean) => readonly [Animated.Value, (...args: any[]) => void, 1 | Animated.AnimatedInterpolation<string | number>, 0 | Animated.AnimatedInterpolation<string | number>, 0 | Animated.AnimatedInterpolation<string | number>];
//# sourceMappingURL=useAnimateScrollView.d.ts.map