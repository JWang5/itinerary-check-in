import React from 'react';
import { FlatList } from 'react-native';
export declare const AnimatedFlatList: React.ForwardRefExoticComponent<import("../types").AnimatedViewProps & import("react-native").FlatListProps<any> & React.RefAttributes<FlatList<any>>>;
//# sourceMappingURL=AnimatedFlatList.d.ts.map