import { ScrollView } from 'react-native';
import React from 'react';
export declare const AnimatedScrollView: React.ForwardRefExoticComponent<import("../types").AnimatedViewProps & import("react-native").ScrollViewProps & React.RefAttributes<ScrollView>>;
//# sourceMappingURL=AnimatedScrollView.d.ts.map