/// <reference types="react" />
import type { AnimatedHeaderProps } from '../types';
export declare const AnimatedHeader: ({ HeaderComponent, headerImage, imageHeight, translateYUp, translateYDown, scale, imageStyle, }: AnimatedHeaderProps) => JSX.Element;
//# sourceMappingURL=AnimatedHeader.d.ts.map